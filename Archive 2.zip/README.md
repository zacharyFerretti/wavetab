# WaveTab - a new tab page for Google Chrome & Firefox!

WaveTab turns each new tab page into a gorgeous, animated gradient! Built with speed and minimalism in mind, there's no clutter or huge files to load. There are plenty of customization options, too!

For more info, visit the [WaveTab website](https://lizgw.github.io/wavetab/).